import WithBookStoreService from './WithBookStoreService';

export default WithBookStoreService;