import ShoppingCartTable from './ShoppingCartTable';

export default ShoppingCartTable;