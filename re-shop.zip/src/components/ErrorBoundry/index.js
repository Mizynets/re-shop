import ErrorBoundry from './ErrorBoundry';

export default ErrorBoundry;